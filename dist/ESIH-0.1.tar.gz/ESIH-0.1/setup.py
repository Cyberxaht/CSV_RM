from setuptools import setup, find_packages

setup(
    name='ESIH',
    version='0.1',
    packages=find_packages(),
    description='Un Programme qui annalyse les fichiers CSV et qui donne des statistiques',
    long_description=open('README.md').read(),
    author='EXALENT/AMAZAN',
    author_email='emaxwisken@gmail.com',
    
)
